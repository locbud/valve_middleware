//--------------------------------------------------------------------------
// File Name		: HW_Define.c
// Author			: SunKyung
// Version			: V1.0
// HomePage			: 
// Date				: 11/01/2017
// Description		: Sikhoon J.
//--------------------------------------------------------------------------
#ifndef __ADC_H
#define __ADC_H
//--------------------------------------------------------------------------
extern idata unsigned short  ADC_BUFF[];
extern idata unsigned char   ADC_SEL;
//--------------------------------------------------------------------------
void Initial_ADC(void);
void Start_ADC(void);
//--------------------------------------------------------------------------
#endif
// End of File

