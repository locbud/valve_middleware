//--------------------------------------------------------------------------
//
//
//
//--------------------------------------------------------------------------
#include <string.h>
#include "REG_MG82FG5Bxx.h"
#include "Define.h"
#include "ADC.h"
//--------------------------------------------------------------------------
idata unsigned short  ADC_BUFF[4] = {0};
idata unsigned char   ADC_SEL = 0;
//--------------------------------------------------------------------------
void Initial_ADC(void)
{
	P1AIO = 0x0F;
	ADCFG0 = ADCKS1 | ADCKS0 | ADRJ;
	ADCFG1 = 0;
	ADCON0 = ADCEN;
//	ADCON0 |= ADCS;
	EIE1 |=  EADC;
}
//--------------------------------------------------------------------------
// Ÿ�̸� ���ͷ�Ʈ 1mSec ���� timer_cnt ����
void RD_ADC(void) interrupt 9 using 2
{
	idata unsigned short  ADC_BUF =  0;
	idata unsigned char c = 0;
	//---
	ADCON0 &= ~ADCS;
	ADC_BUF = ((ADCDH & 0x03) << 8) + ADCDL; 
	//---
	ADC_BUFF[ADC_SEL] = ADC_BUF;
	ADC_SEL++; if(ADC_SEL >= 4) ADC_SEL = 0;
//	ADCON0 |= ADCS;
}
//--------------------------------------------------------------------------
void Start_ADC(void)
{
	ADCON0 |= ADCS;
}
//--------------------------------------------------------------------------
// End of File
