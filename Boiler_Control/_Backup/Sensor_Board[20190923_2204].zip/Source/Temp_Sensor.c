//--------------------------------------------------------------------------
//
//--------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "REG_MG82FG5Bxx.h"
#include "Define.h"
#include "SetDRV.h"
#include "Time2.h"
#include "Uart.h"
#include "Modbus.h"
#include "ADC.h"
//--------------------------------------------------------------------------
idata unsigned char  Not_Conn = 0;
//---
Type_Temp	mDB;
//--------------------------------------------------------------------------
void main( void )
{
	idata Type_ModbusRTU 	DaA;
	//---
	Ser_OSC();
	//---
    Initial_Timer2();
#if(Uart1)
	Initial_UART0(BR_9600);
#endif
#if(Uart2)
	Initial_UART1(BR_9600);
#endif
	IO_Map_Init();
	Initial_ADC();
    EA=1;
	LED1_FG = 0;
	LED2_FG = 0;
	LED_OnOff(1, 0);
	LED_OnOff(2, 0);
    //---
	RF_Set(0x98);
#if(Uart1)
    Tx1_FG = 0;
	Rx1_FG = 0;
	Rx1_CP = 0;
#endif
#if(Uart2)
    Tx2_FG = 0;
	Rx2_FG = 0;
	Rx2_CP = 0;
#endif
    //---
	mDB.TH = 0.0;
	mDB.TL = 0.0;
	mDB.VO = 0.0;
	mDB.CU = 0.0;
	mDB.Do = 0;
	//---
//	DaA.CMD = RTU_CMD;
//	DaA.Add = RTU_S_Addr;
//	DaA.No  = RTU_S_Len;
//	j = TX_M_MODBUS_RTU(2, DaA);
//	Send_Tx2();
	//---
	WDT_INIT();
	//---
    while(1){
		//---
#if(Uart1)
        if(Rx1_CP){
        	Rx1_CP = 0;
			RX_S_MODBUS_RTU(1, Rx1_Buf, Rx1_CNT);
			
//			Conn1_FG = 1;
		}
#endif
		//---
#if(Uart2)
        if(Rx2_CP){
        	Rx2_CP = 0;
//			RX_M_MODBUS_RTU(2, Rx2_Buf, Rx2_CNT);
//			Conn2_FG = 1;
			Not_Conn = 0;
        }
#endif
		//---
		if(FG_T10mS){
			FG_T10mS = 0;
		}
		//---
		if(FG_T100mS){
			FG_T100mS = 0;
			//---
//			Start_ADC();
			//---
			LED1_FG++;
			if(LED1_FG >= 10){
				LED1_FG = 0;
				LED_OnOff(1, 0);
			} else if(LED1_FG == 5){
				LED_OnOff(1, 1);
			}
		}
		//---
		if(FG_T1S){
			FG_T1S = 0;
			//---
#if(Uart2)
			Send_Tx2("bbbbb", 4);
#endif
#if(Uart1)
			Send_Tx1("aaaaa", 4);
#endif
			//---
			Not_Conn++;
			//---
			if(Not_Conn >= 10){
				Not_Conn = 0;
			}
		}
		//---
		WDTCR |= CLW;
    }
}
//--------------------------------------------------------------------------
// End of File
