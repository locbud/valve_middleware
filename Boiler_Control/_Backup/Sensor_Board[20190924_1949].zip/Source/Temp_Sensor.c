//--------------------------------------------------------------------------
//
//--------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "REG_MG82FG5Bxx.h"
#include "Define.h"
#include "SetDRV.h"
#include "Time2.h"
#include "Uart.h"
#include "Modbus.h"
#include "ADC.h"
//--------------------------------------------------------------------------
idata unsigned char  Not_Conn = 0;
//---
Type_Temp	mDB;
//--------------------------------------------------------------------------
void ADC_Updata(void)
{
	DWORD DW;
	//---
	mDB.TH = (ADC_BUFF[ADC_TH] * ADC_SCALE[ADC_TH]) + ADC_ZERO[ADC_TH];
	mDB.TL = (ADC_BUFF[ADC_TL] * ADC_SCALE[ADC_TL]) + ADC_ZERO[ADC_TL];
	mDB.VO = (ADC_BUFF[ADC_VO] * ADC_SCALE[ADC_VO]) + ADC_ZERO[ADC_VO];
	mDB.CU = (ADC_BUFF[ADC_CU] * ADC_SCALE[ADC_CU]) + ADC_ZERO[ADC_CU];
	DW.F = mDB.TH; mDB_MAP[MA_TH] = DW.W[0]; mDB_MAP[MA_TH+1] = DW.W[1];
	DW.F = mDB.TL; mDB_MAP[MA_TL] = DW.W[0]; mDB_MAP[MA_TL+1] = DW.W[1];
	DW.F = mDB.VO; mDB_MAP[MA_VO] = DW.W[0]; mDB_MAP[MA_VO+1] = DW.W[1];
	DW.F = mDB.CU; mDB_MAP[MA_CU] = DW.W[0]; mDB_MAP[MA_CU+1] = DW.W[1];
}
//--------------------------------------------------------------------------
void main( void )
{
	DWORD DW;
	int i = 0;
	idata Type_ModbusRTU 	DaA;
	//---
	Ser_OSC();
	//---
    Initial_Timer2();
	Initial_UART0(BR_9600);
	IO_Map_Init();
	Initial_ADC(0);
    EA=1;
	LED1_FG = 0;
	LED2_FG = 0;
	LED_OnOff(1, 0);
	LED_OnOff(2, 0);
    //---
	RF_Set(0x98);
	for(i = 0; i < 4; i++){
		ADC_SCALE[i] = 1.0;
		ADC_ZERO[i] = 0;
	}
    Tx1_FG = 0;
	Rx1_FG = 0;
	Rx1_CP = 0;
    //---
#if(MB_MT)
	mDB.TH = 0.0;
	mDB.TL = 0.0;
	mDB.VO = 0.0;
	mDB.CU = 0.0;
	mDB.Do = 0;
#else
	mDB.TH = 70.0;
	mDB.TL = 30.0;
	mDB.VO = 1.5;
	mDB.CU = 0.5;
	mDB.Do = 0x003F;
	mDB.ST = 0x0;
#endif
	//---
	DaA.ID  = RTU_aID;
	DaA.CMD = RTU_CMD;
	DaA.Add = RTU_Addr;
	DaA.No  = RTU_Len;
	//---
	WDT_INIT();
	//---
    while(1){
		//---
        if(Rx1_CP){
        	Rx1_CP = 0;
#if(MB_MT)
			RX_M_MODBUS_RTU(1, Rx1_tBuf, Rx1_tCNT);
			//---
			mDB.ST = mDB_MAP[MA_STATE];
			mDB.Do = mDB_MAP[MA_SET];
			DW.W[0] = mDB_MAP[MA_TH]; DW.W[1] = mDB_MAP[MA_TH+1]; mDB.TH = DW.F;
			DW.W[0] = mDB_MAP[MA_TL]; DW.W[1] = mDB_MAP[MA_TL+1]; mDB.TL = DW.F;
			DW.W[0] = mDB_MAP[MA_VO]; DW.W[1] = mDB_MAP[MA_VO+1]; mDB.VO = DW.F;
			DW.W[0] = mDB_MAP[MA_CU]; DW.W[1] = mDB_MAP[MA_CU+1]; mDB.CU = DW.F;
#else
			RX_S_MODBUS_RTU(1, Rx1_Buf, Rx1_CNT);
#endif
//			Conn1_FG = 1;
		}
		//---
		if(FG_T10mS){
			FG_T10mS = 0;
			switch(ADC_SEL){
				case ADC_TH: Select_ADC(ADC_TH); ADC_BUFF[ADC_TH] = Read_ADC(); ADC_SEL = ADC_TL; break;
				case ADC_TL: Select_ADC(ADC_TL); ADC_BUFF[ADC_TL] = Read_ADC(); ADC_SEL = ADC_VO; break;
				case ADC_VO: Select_ADC(ADC_VO); ADC_BUFF[ADC_VO] = Read_ADC(); ADC_SEL = ADC_CU; break;
				case ADC_CU: Select_ADC(ADC_CU); ADC_BUFF[ADC_CU] = Read_ADC(); ADC_SEL = ADC_TH; break;
//				default: break;
			}
		}
		//---
		if(FG_T100mS){
			FG_T100mS = 0;
			//---
			ADC_Updata();
//			Start_ADC();
			//---
/*
			mDB_MAP[MA_STATE] = mDB.ST;
			mDB_MAP[MA_SET] = mDB.Do;
*/
			//---
			LED1_FG++;
			if(LED1_FG >= 10){
				LED1_FG = 0;
				LED_OnOff(1, 0);
			} else if(LED1_FG == 5){
				LED_OnOff(1, 1);
			}
		}
		//---
		if(FG_T1S){
			FG_T1S = 0;
			//---
#if(MB_MT)
			TX_M_MODBUS_RTU(1, DaA);
#endif
			//---
			Not_Conn++;
			//---
			if(Not_Conn >= 10){
				Not_Conn = 0;
			}
		}
		//---
		WDTCR |= CLW;
    }
}
//--------------------------------------------------------------------------
// End of File
